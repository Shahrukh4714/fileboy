import os
import uuid
import subprocess
import shutil
from flask import Flask, request, jsonify, send_file
from flask_cors import CORS
from PIL import Image
import img2pdf
from pdf2image import convert_from_path
from pypdf import PdfReader, PdfWriter
import pikepdf

app = Flask(__name__)
CORS(app)

UPLOAD_DIR = "/tmp/fileboy/uploads"
OUTPUT_DIR = "/tmp/fileboy/outputs"
os.makedirs(UPLOAD_DIR, exist_ok=True)
os.makedirs(OUTPUT_DIR, exist_ok=True)

IMAGE_FORMATS = {"jpeg", "jpg", "png", "webp", "gif", "bmp", "tiff"}
VIDEO_FORMATS = {"mp4", "mov", "webm", "avi", "mkv", "gif"}
AUDIO_FORMATS = {"mp3", "wav", "aac", "flac", "ogg", "m4a"}
DOC_FORMATS = {"pdf", "docx", "doc", "pptx", "ppt", "xlsx", "xls", "odt", "txt"}

def get_ext(filename):
    return filename.rsplit(".", 1)[-1].lower() if "." in filename else ""

def detect_category(ext):
    if ext in IMAGE_FORMATS: return "image"
    if ext in VIDEO_FORMATS: return "video"
    if ext in AUDIO_FORMATS: return "audio"
    if ext in DOC_FORMATS: return "document"
    return "unknown"


@app.route("/api/detect", methods=["POST"])
def detect():
    """Given a filename, return category + available target formats."""
    filename = request.json.get("filename", "")
    ext = get_ext(filename)
    category = detect_category(ext)

    targets = {
        "image": ["jpeg", "png", "webp", "gif", "bmp", "pdf"],
        "video": ["mp4", "mov", "webm", "gif", "mp3"],  # mp3 = extract audio
        "audio": ["mp3", "wav", "aac", "flac", "ogg"],
        "document": ["pdf", "docx", "pptx", "xlsx", "txt"],
        "unknown": []
    }

    return jsonify({
        "category": category,
        "source_ext": ext,
        "available_targets": [t for t in targets.get(category, []) if t != ext]
    })


@app.route("/api/convert", methods=["POST"])
def convert():
    if "file" not in request.files:
        return jsonify({"error": "No file provided"}), 400

    file = request.files["file"]
    target_format = request.form.get("target", "").lower()
    if not target_format:
        return jsonify({"error": "No target format specified"}), 400

    job_id = str(uuid.uuid4())[:8]
    original_name = file.filename
    source_ext = get_ext(original_name)
    base_name = original_name.rsplit(".", 1)[0] if "." in original_name else original_name

    input_path = os.path.join(UPLOAD_DIR, f"{job_id}_{original_name}")
    file.save(input_path)
    original_size = os.path.getsize(input_path)

    output_filename = f"{base_name}.{target_format}"
    output_path = os.path.join(OUTPUT_DIR, f"{job_id}_{output_filename}")

    category = detect_category(source_ext)

    try:
        if category == "image":
            convert_image(input_path, output_path, target_format)
        elif category == "video":
            convert_video(input_path, output_path, target_format)
        elif category == "audio":
            convert_audio(input_path, output_path, target_format)
        elif category == "document":
            convert_document(input_path, output_path, target_format, job_id)
        else:
            return jsonify({"error": f"Unsupported file type: {source_ext}"}), 400

        if not os.path.exists(output_path):
            return jsonify({"error": "Conversion produced no output"}), 500

        new_size = os.path.getsize(output_path)

        return jsonify({
            "success": True,
            "job_id": job_id,
            "output_filename": output_filename,
            "download_url": f"/api/download/{job_id}/{output_filename}",
            "original_size": original_size,
            "new_size": new_size,
        })

    except subprocess.CalledProcessError as e:
        return jsonify({"error": f"Conversion failed: {str(e)}"}), 500
    except Exception as e:
        return jsonify({"error": str(e)}), 500
    finally:
        if os.path.exists(input_path):
            os.remove(input_path)


def convert_image(input_path, output_path, target_format):
    img = Image.open(input_path)

    if target_format == "pdf":
        rgb = img.convert("RGB")
        rgb.save(output_path, "PDF")
        return

    if target_format in ("jpeg", "jpg") and img.mode in ("RGBA", "P"):
        img = img.convert("RGB")

    save_format = "JPEG" if target_format in ("jpeg", "jpg") else target_format.upper()
    img.save(output_path, save_format)


def convert_video(input_path, output_path, target_format):
    if target_format == "mp3":
        cmd = ["ffmpeg", "-y", "-i", input_path, "-vn", "-acodec", "libmp3lame", output_path]
    elif target_format == "gif":
        cmd = ["ffmpeg", "-y", "-i", input_path, "-vf", "fps=10,scale=480:-1:flags=lanczos", output_path]
    else:
        cmd = ["ffmpeg", "-y", "-i", input_path, "-c:v", "libx264", "-c:a", "aac", output_path]
    subprocess.run(cmd, check=True, capture_output=True)


def convert_audio(input_path, output_path, target_format):
    cmd = ["ffmpeg", "-y", "-i", input_path, output_path]
    subprocess.run(cmd, check=True, capture_output=True)


def convert_document(input_path, output_path, target_format, job_id):
    source_ext = get_ext(input_path)

    # PDF -> other document formats, or doc formats -> PDF: use LibreOffice headless
    if target_format == "pdf" or source_ext == "pdf":
        outdir = os.path.join(OUTPUT_DIR, job_id)
        os.makedirs(outdir, exist_ok=True)
        cmd = [
            "soffice", "--headless", "--convert-to", target_format,
            "--outdir", outdir, input_path
        ]
        subprocess.run(cmd, check=True, capture_output=True, timeout=60)

        produced = [f for f in os.listdir(outdir) if f.endswith(f".{target_format}")]
        if produced:
            shutil.move(os.path.join(outdir, produced[0]), output_path)
        shutil.rmtree(outdir, ignore_errors=True)
    else:
        # doc -> doc (non-pdf): go via pdf as intermediate through LibreOffice directly
        outdir = os.path.join(OUTPUT_DIR, job_id)
        os.makedirs(outdir, exist_ok=True)
        cmd = [
            "soffice", "--headless", "--convert-to", target_format,
            "--outdir", outdir, input_path
        ]
        subprocess.run(cmd, check=True, capture_output=True, timeout=60)
        produced = [f for f in os.listdir(outdir) if f.endswith(f".{target_format}")]
        if produced:
            shutil.move(os.path.join(outdir, produced[0]), output_path)
        shutil.rmtree(outdir, ignore_errors=True)


@app.route("/api/download/<job_id>/<filename>")
def download(job_id, filename):
    path = os.path.join(OUTPUT_DIR, f"{job_id}_{filename}")
    if not os.path.exists(path):
        return jsonify({"error": "File not found"}), 404
    return send_file(path, as_attachment=True, download_name=filename)


@app.route("/api/health")
def health():
    return jsonify({"status": "ok"})


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5050, debug=False)
